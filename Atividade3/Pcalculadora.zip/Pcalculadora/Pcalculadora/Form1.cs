﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalculadora
{
    public partial class Form1 : Form
    {
        Double num1;
        Double num2;
        Double result;

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show ("Deseja sair?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question)==DialogResult.Yes){
                Close();

            }
            else
            {

            }
        }

        private void BtnMenos_Click(object sender, EventArgs e)
        {
            result = num1 - num2;
            txtResultado.Text = result.ToString();

        }

        private void Btnresultiplicacao_Click(object sender, EventArgs e)
        {
            result = num1 * num2;
            txtResultado.Text = result.ToString();
        }

        private void Btnresultisao_Click(object sender, EventArgs e)
        {
            if (num2 > 0)
            {
                result = num1 / num2;
                txtResultado.Text = result.ToString();
            }
            else
                MessageBox.Show("Número 2 inválido");
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }

        private void TxtNumero1_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtNumero1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero1.Text, out num1))
            {
                MessageBox.Show("Número inválido!");
                txtNumero1.Focus();

            }
        }

        private void TxtNumero2_Validated(object sender, EventArgs e)
        {

            if (!double.TryParse(txtNumero2.Text, out num2))
            {
                MessageBox.Show("Caracter inválido!");
                txtNumero2.Focus();
            }
        }

        private void BtnMais_Click(object sender, EventArgs e)
        {
            result = num1 + num2;
            txtResultado.Text = result.ToString();
        }

        private void BtnDivisao_Click(object sender, EventArgs e)
        {
            if (num2 > 0)
            {
                result = num1 / num2;
                txtResultado.Text = result.ToString();
            }
            else
            {
                MessageBox.Show("Divisão por zero.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNumero2.Focus();

            }
        }

        private void BtnMultiplicacao_Click(object sender, EventArgs e)
        {
            result = num1 * num2;
            txtResultado.Text = result.ToString();
        }
    }
}