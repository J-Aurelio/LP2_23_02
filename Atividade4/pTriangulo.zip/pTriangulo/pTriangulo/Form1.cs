﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pTriangulo
{
    public partial class Form1 : Form
    {

        private void TxtValor1_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtValorA, "");
            double valorA;

            if (!double.TryParse(txtValorA.Text, out valorA)) {
                errorProvider1.SetError(txtValorA, "Valor A inválido.");
                //MessageBox.Show("Número inválido!");
                //txtValor1.Focus();

            }
        }

        private void TxtValor2_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtValorB, "");
            double valorB;

            if (!double.TryParse(txtValorB.Text, out valorB))
            {
                errorProvider2.SetError(txtValorB, "Valor B inválido.");

            }
        }

        private void TxtValor3_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(txtValorC, "");
            double valorC;

            if (!double.TryParse(txtValorC.Text, out valorC))
            {
                errorProvider3.SetError(txtValorC, "Valor B inválido.");

            }
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();

            }
            else
            {

            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            double valorA, valorB, valorC;
            //testar se os valores são válidos
            if (!double.TryParse(txtValorA.Text, out valorA) || !double.TryParse(txtValorB.Text, out valorB) || !double.TryParse(txtValorC.Text, out valorC))
            {
                MessageBox.Show("Valores devem ser numéricos");
            }
            else
            {
                if (valorA < (valorB + valorC) && valorA > Math.Abs(valorB - valorC) && valorB<(valorA+valorC)&& valorB>Math.Abs(valorA-valorC) && valorC < (valorA + valorB) && valorC > Math.Abs(valorA - valorB))
                {
                    if ((valorA == valorB) && (valorB== valorC))
                        MessageBox.Show($"os valores {valorA}, {valorB} e {valorC} formam um triangulo equilatero");
                    else if (valorA == valorB || valorA == valorC || valorB == valorC)
                        MessageBox.Show($"os valores {valorA}, {valorB} e {valorC} formam um triangulo escaleno");
                    else
                        MessageBox.Show($"os valores {valorA}, {valorB} e {valorC} formam um triangulo isóceles");

                }
                else
                    MessageBox.Show($"os valores {valorA}, {valorB} e {valorC} NÃO formam um triangulo");
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();
        }
    }
}
