﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PCotacao
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnExecutar_Click(object sender, EventArgs e)
        {
            double[,] mNtb = new double[6, 3];
            string auxiliar = "";
            for (var i = 0; i < 3; i++)
            {
                for (var j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite o valor do notebook {i + 1} da Loja {j + 1}", "Entrada dos valores");
                    if (Convert.ToDouble(auxiliar) > 0)
                    {
                        mNtb[i, j] = Convert.ToDouble(auxiliar);
                        lstbxNotebook.Items.Add($"Notebook {i + 1} Loja {j + 1}");
                    }
                    else
                        j++;
                        
                }
                    
            }
        }
    }
}
